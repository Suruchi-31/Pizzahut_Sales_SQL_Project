create database pizzahut;
create table pizzas(
  pizza_id text,
  pizza_type_id text,
  size text,
  price double precision 
  
);

 select * from pizzas;

create table pizza_types(
  pizza_type_id text,
  name text,
  category text,
  ingredients text
  
);

 select * from pizza_types;

create table orders(
 order_id int not null,
 order_date date not null,
 order_time time not null,
 primary key(order_id)
 );

 select * from orders;

 create table orders_details(
 order_details_id int not null,
 order_id int not null,
 pizza_id text not null,
 quantity int not null,
 primary key(order_details_id)
 );
 
select * from orders_details;

 select * from pizzas;
 select * from pizza_types;
 select * from orders;
 select * from orders_details;
 --Question--
--Q1) Retrieve the total number of order placed.
  select count(order_id) as Total_orders_placed from orders;

--Q2) Calculate the total revenue generated from pizza_sales
   select 
   sum((orders_details.quantity * pizzas.price))as Total_Revenue
   from orders_details JOIN pizzas
   ON pizzas.pizza_id = orders_details.pizza_id;

   --If want to round off upto 2 digits then
   select 
   round(sum(orders_details.quantity * pizzas.price)::NUMERIC,2)as Total_Revenue
   from orders_details 
   JOIN pizzas
   ON pizzas.pizza_id = orders_details.pizza_id;

--Q3) Identify the highest priced pizza
  select pizza_types.name, pizzas.price
  FROM pizza_types 
  Join pizzas
  ON pizza_types.pizza_type_id = pizzas.pizza_type_id
  ORDER BY pizzas.price desc limit 1;

--Q4) Identify the most common pizza size order
    select pizzas.size,count(orders_details.order_details_id)as order_count from pizzas
	JOIN orders_details 
	ON pizzas.pizza_id = orders_details.pizza_id
	group by pizzas.size order by  order_count desc ;

--Q5) list the 5 most ordered pizza types along with its quantity
     select pizzas.pizza_id, sum(orders_details.quantity) as total_quantity
     from pizzas
	 JOIN orders_details 
	 ON pizzas.pizza_id = orders_details.pizza_id
	 group by pizzas.pizza_id order by total_quantity desc limit 5 ;
-- Since in the above query, we get the most ordered pizza_id and not pizza_name
-- So, here is the naother query to get pizza_name

     select pizza_types.name,sum(orders_details.quantity) as total_quantity
     from pizza_types
	 JOIN pizzas ON
	 pizza_types.pizza_type_id = pizzas.pizza_type_id
     JOIN orders_details
	 ON pizzas.pizza_id = orders_details.pizza_id
	 group by pizza_types.name order by total_quantity desc limit 5 ;
	 
-- Intermediate Question
-- Q1) Join the neccessary table to find the total quantity of each pizza category ordered
     select pizza_types.category, sum(orders_details.quantity) as Total_Quantity
	 from pizza_types
	 JOIN pizzas ON
	 pizza_types.pizza_type_id = pizzas.pizza_type_id
	 JOIN orders_details ON
	 pizzas.pizza_id = orders_details.pizza_id
	 group by  pizza_types.category order by Total_Quantity ;

--Q2) Determine the distribution of orders by hour of the day
     select EXTRACT(hour from order_time) as Hours, count(orders.order_id)
	 from orders group by EXTRACT(hour from order_time) order by Hours;

--Q3) join the relevant table to find the category wise distribution of pizzas
      --category wise
	  ---pizza
	  select pizza_types.category, count(order_id) as Count
	  from pizza_types 
	  JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
	  JOIN orders_details ON pizzas.pizza_id = orders_details.pizza_id
	  group by pizza_types.category;

	  select category, count(name) 
	  from pizza_types group by category; 

--Q4)Group the order by date and calculate the average number of pizzas ordered per day.
      select ROUND(avg( total_pizza_ordered),0) as Average_pizza_ordered_per_day
	  from(
	  select orders.order_date, sum(orders_details.quantity) as total_pizza_ordered
	  from orders 
	  JOIN orders_details ON
	  orders.order_id = orders_details.order_id
	  group by orders.order_date
	  );

--Q5) Determine the top 3 most ordered pizza types based on revenue.
    -- total revenue of each pizza type
	-- top 3(total revenue of each pizza type)
	select pizza_types.name,sum(orders_details.quantity * pizzas.price) as Total_Revenue
	from pizza_types
	JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
	JOIN orders_details ON pizzas.pizza_id = orders_details.pizza_id
	group by pizza_types.name order by Total_Revenue desc limit 3;

----ADVANCED QUESTIONS-----
--Q1) calculate the percentagae contribution of each pizza type to toal revenue
     with total_revenue_of_all_category as
	 (
        select round(sum(orders_details.quantity * pizzas.price)::NUMERIC,2) as revenue
		from orders_details
		JOIN pizzas ON pizzas.pizza_id = orders_details.pizza_id
	 ) 
     select pizza_types.category,sum(orders_details.quantity * pizzas.price)/
	 tr.revenue
	 * 100 as Total_Revenue_categorywise
	from pizza_types
	JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
	JOIN orders_details ON pizzas.pizza_id = orders_details.pizza_id
	CROSS JOIN total_revenue_of_all_category tr
	group by pizza_types.category,tr.revenue
	order by Total_Revenue_categorywise;

  ---Another Alternative---
    select pizza_types.category, 
	sum(orders_details.quantity * pizzas.price)*100/
	 (select round(sum(orders_details.quantity * pizzas.price):: Numeric,2)
	 as Combined_revenue_of_all_category
	 from pizzas
	 JOIN orders_details ON
	 pizzas.pizza_id = orders_details.pizza_id)
	
	 
		  as revenue_per_category
		  from pizza_types
		JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
		JOIN orders_details ON pizzas.pizza_id = orders_details.pizza_id
		group by pizza_types.category
		order by revenue_per_category
		;
--Q2) Anayse the cumulative revenue generated over time

   --       Income   Cumulative Revenue
   --Day 1-> 200        200
   --Day 2--> 300      200+300=500
   --Day 3--> 450     200+300+450=950
   --Day 4--> 250      950+250=1200
   
     select order_date,
	 sum(total_revenue) over(order by order_date) as cum_revenue
	 from(select orders.order_date,
	  sum(orders_details.quantity * pizzas.price) as total_revenue
	  from orders_details JOIN pizzas
	  ON orders_details.pizza_id = pizzas.pizza_id 
	  JOIN orders ON orders.order_id= orders_details.order_id
	  group by order_date
	 ) as Sales;


--Q4) Determine the top 3 most ordered pizza types based on revenue for each pizza category
     select category,name,revenue from
	  (select category,name,revenue,
		  rank() over(partition by category order by revenue desc ) as rnk
			  from(
					  select pizza_types.category, pizza_types.name,
					  sum((orders_details.quantity) * pizzas.price) as revenue
					  from pizza_types JOIN pizzas
					  ON pizza_types.pizza_type_id = pizzas.pizza_type_id
					  JOIN orders_details ON
					  orders_details.pizza_id = pizzas.pizza_id
					  group by pizza_types.category, pizza_types.name )as A) as B
	  where rnk<=3;